import { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { IncrawlError, login, signup } from '../utils/incrawl';
import { LightReader, shadows } from '../components/theme';

export default function LoginScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [referrer, setReferrer] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);

  const submit = async () => {
    if (busy) return;
    if (!email.trim() || !password) { setError('Enter your email and password.'); return; }
    setBusy(true); setError('');
    try {
      if (mode === 'login') await login(email, password);
      else await signup(email, password, referrer);
      router.replace('/');
    } catch (e) {
      if (e instanceof IncrawlError && e.status === 0) setError('Cannot reach the server. Check your connection and try again.');
      else setError(e instanceof Error ? e.message : 'Something went wrong.');
    } finally { setBusy(false); }
  };

  return (
    <View style={[styles.screen, { paddingBottom: insets.bottom + 20 }]}>
      <View style={styles.card}>
        <View style={styles.logo}><Text style={styles.logoText}>P</Text></View>
        <Text style={styles.title}>{mode === 'login' ? 'Welcome back' : 'Create your account'}</Text>
        <Text style={styles.sub}>Sign in to load the live Incrawl library on Paper.</Text>

        <View style={styles.inputWrap}>
          <Ionicons name="mail-outline" size={19} color={LightReader.muted} />
          <TextInput value={email} onChangeText={setEmail} placeholder="Email" placeholderTextColor={LightReader.muted} style={styles.input} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" />
        </View>
        <View style={styles.inputWrap}>
          <Ionicons name="lock-closed-outline" size={19} color={LightReader.muted} />
          <TextInput value={password} onChangeText={setPassword} placeholder="Password" placeholderTextColor={LightReader.muted} style={styles.input} secureTextEntry={!showPass} autoCapitalize="none" autoCorrect={false} />
          <Pressable onPress={() => setShowPass((v) => !v)} hitSlop={10} accessibilityLabel={showPass ? 'Hide password' : 'Show password'}>
            <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={19} color={LightReader.muted} />
          </Pressable>
        </View>
        {mode === 'signup' && (
          <View style={styles.inputWrap}>
            <Ionicons name="ticket-outline" size={19} color={LightReader.muted} />
            <TextInput value={referrer} onChangeText={setReferrer} placeholder="Referrer code (if you have one)" placeholderTextColor={LightReader.muted} style={styles.input} autoCapitalize="none" autoCorrect={false} />
          </View>
        )}

        {error ? <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={16} color={LightReader.red} /><Text style={styles.errorText}>{error}</Text></View> : null}

        <Pressable onPress={submit} style={[styles.button, busy && styles.disabled]} accessibilityRole="button">
          <Text style={styles.buttonText}>{busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Sign up'}</Text>
        </Pressable>

        <Pressable onPress={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }} accessibilityRole="button">
          <Text style={styles.switch}>{mode === 'login' ? 'New here? Create an account' : 'Already have an account? Log in'}</Text>
        </Pressable>
        <Pressable onPress={() => router.replace('/')} accessibilityRole="button">
          <Text style={styles.skip}>Continue without live library</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: LightReader.background, justifyContent: 'center', paddingHorizontal: 20 },
  card: { padding: 22, borderRadius: 24, backgroundColor: LightReader.surface, borderWidth: 1, borderColor: LightReader.borderSoft, gap: 12, ...shadows.pop },
  logo: { width: 54, height: 54, borderRadius: 16, backgroundColor: LightReader.accent, alignItems: 'center', justifyContent: 'center' },
  logoText: { color: '#FFFFFF', fontSize: 28, fontWeight: '800' },
  title: { fontSize: 26, fontWeight: '800', color: LightReader.text, marginTop: 6 },
  sub: { color: LightReader.textSecondary, fontSize: 14, lineHeight: 20 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: LightReader.surfaceSoft, borderWidth: 1, borderColor: LightReader.borderSoft, borderRadius: 14, paddingHorizontal: 14 },
  input: { flex: 1, color: LightReader.text, paddingVertical: 14, fontSize: 15 },
  errorBox: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderRadius: 12, backgroundColor: '#FDECEF' },
  errorText: { color: LightReader.red, fontSize: 13, flex: 1, lineHeight: 17 },
  button: { height: 52, borderRadius: 14, backgroundColor: LightReader.accent, alignItems: 'center', justifyContent: 'center' },
  disabled: { opacity: 0.6 },
  buttonText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
  switch: { color: LightReader.accent, textAlign: 'center', marginTop: 6, fontWeight: '700', fontSize: 14 },
  skip: { color: LightReader.muted, textAlign: 'center', fontSize: 14 },
});
