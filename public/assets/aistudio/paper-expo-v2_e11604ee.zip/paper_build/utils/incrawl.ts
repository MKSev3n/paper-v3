import AsyncStorage from '@react-native-async-storage/async-storage';

export const INCRAWL_BASE_URL = 'https://lightnovel-crawler-vit0.onrender.com';

const TOKEN_KEY = '@paper/incrawl-token:v1';

// --- API types (from https://lightnovel-crawler-vit0.onrender.com/openapi.json) ---
export interface ApiNovel {
  id: string;
  domain: string;
  url: string;
  title: string;
  authors?: string | null;
  synopsis?: string | null;
  tags?: string[];
  cover_url?: string | null;
  volume_count?: number;
  chapter_count?: number;
  popularity?: number;
  language?: string | null;
  mtl?: boolean;
}

export interface ApiChapter {
  id: string;
  novel_id: string;
  serial: number;
  volume_id?: string | null;
  url: string;
  title: string;
  is_done?: boolean;
  is_available?: boolean;
}

export interface ReadChapterResponse {
  novel: ApiNovel;
  chapter: ApiChapter;
  content?: string | null;
  next_id?: string | null;
  previous_id?: string | null;
  language?: string | null;
  word_count?: number | null;
}

export interface Paginated<T> {
  total: number;
  offset: number;
  limit: number;
  items: T[];
}

export interface ApiUser {
  id: string;
  email: string;
  name?: string | null;
  is_verified?: boolean;
}

export class IncrawlError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function getToken(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export async function setToken(token: string | null): Promise<void> {
  try {
    if (token) await AsyncStorage.setItem(TOKEN_KEY, token);
    else await AsyncStorage.removeItem(TOKEN_KEY);
  } catch (error) {
    console.warn('[incrawl] token save failed', error);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const token = await getToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  let response: Response;
  try {
    response = await fetch(`${INCRAWL_BASE_URL}${path}`, { ...init, headers });
  } catch {
    throw new IncrawlError(0, 'cannot reach server, check connection');
  }
  if (response.status === 401) {
    throw new IncrawlError(401, 'not logged in');
  }
  if (!response.ok) {
    let detail = `request failed (${response.status})`;
    try {
      const body: any = await response.json();
      if (body?.detail) detail = String(body.detail);
      else if (body?.error) detail = String(body.error);
    } catch {}
    throw new IncrawlError(response.status, detail);
  }
  return (await response.json()) as T;
}

export async function login(email: string, password: string): Promise<ApiUser> {
  const data = await request<{ token: string; user: ApiUser }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: email.trim(), password }),
  });
  await setToken(data.token);
  return data.user;
}

// signup needs a referrer token (required by the API). pass '' if you have none and see if server accepts it.
export async function signup(email: string, password: string, referrer = '', name?: string): Promise<ApiUser> {
  const data = await request<{ token: string; user: ApiUser }>('/api/auth/signup', {
    method: 'POST',
    body: JSON.stringify({ referrer, email: email.trim(), password, name: name || null }),
  });
  await setToken(data.token);
  return data.user;
}

export async function me(): Promise<ApiUser> {
  return request<ApiUser>('/api/auth/me');
}

export async function checkHealth(): Promise<{ status: string; version: string }> {
  const res = await fetch(`${INCRAWL_BASE_URL}/health`);
  return res.json();
}

export type NovelSort = 'popular' | 'updated' | 'created' | 'chapters' | 'title_asc' | 'title_desc';

export async function listNovels(params: {
  search?: string;
  offset?: number;
  limit?: number;
  sort?: NovelSort;
} = {}): Promise<Paginated<ApiNovel>> {
  const q = new URLSearchParams();
  if (params.search) q.set('search', params.search);
  q.set('offset', String(params.offset ?? 0));
  q.set('limit', String(params.limit ?? 20));
  q.set('sort', params.sort ?? 'updated');
  return request<Paginated<ApiNovel>>(`/api/novels?${q.toString()}`);
}

export async function getNovel(novelId: string): Promise<ApiNovel> {
  return request<ApiNovel>(`/api/novel/${encodeURIComponent(novelId)}`);
}

export async function getChapters(novelId: string, limit = 100): Promise<Paginated<ApiChapter>> {
  return request<Paginated<ApiChapter>>(
    `/api/novel/${encodeURIComponent(novelId)}/chapters?offset=0&limit=${limit}`,
  );
}

// content comes back as a single string (often HTML). split into plain paragraphs.
export function contentToParagraphs(content: string | null | undefined): string[] {
  if (!content) return [];
  const text = content
    .replace(/<\s*br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'");
  return text
    .split(/\n{1,}/)
    .map((p) => p.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean);
}

export async function readChapter(chapterId: string, autoFetch = true): Promise<ReadChapterResponse> {
  const q = autoFetch ? '?auto_fetch=true' : '';
  return request<ReadChapterResponse>(`/api/chapter/${encodeURIComponent(chapterId)}/read${q}`);
}

// map API novel onto the shape the library card already uses
export interface LiveNovel {
  id: string;
  title: string;
  author: string;
  tags: string[];
  status: 'Ongoing' | 'Completed' | 'Hiatus';
  chapterCount: number;
  coverColor: string;
  synopsis: string;
  live: true;
}

const COVER_COLORS = ['#7A4B2A', '#24506B', '#8A3A52', '#3F6B4F', '#5B4B8A', '#8A5A2B'];

export function mapApiNovel(novel: ApiNovel): LiveNovel {
  let hash = 0;
  for (const ch of novel.id) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return {
    id: novel.id,
    title: novel.title,
    author: novel.authors || novel.domain || 'Unknown',
    tags: novel.tags?.length ? novel.tags : [novel.domain].filter(Boolean),
    status: 'Ongoing',
    chapterCount: novel.chapter_count ?? 0,
    coverColor: COVER_COLORS[hash % COVER_COLORS.length],
    synopsis: novel.synopsis || 'No synopsis yet.',
    live: true,
  };
}
