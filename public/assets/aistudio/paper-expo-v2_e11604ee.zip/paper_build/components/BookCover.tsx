import { StyleSheet, Text, View } from 'react-native';
import { LightReader, SERIF } from './theme';

const ACCENTS = [LightReader.accent, LightReader.lilac, '#2AA198', '#E07A5F', '#5BA4CF', '#9B7EDE'];

export function hashColor(id: string): string {
  let h = 0;
  for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return ACCENTS[h % ACCENTS.length];
}

export function BookCover({
  id, title, author, color, size = 'md',
}: {
  id: string; title: string; author: string; color?: string; size?: 'sm' | 'md' | 'lg';
}) {
  const bg = color && color !== '#FFFFFF' ? color : hashColor(id);
  const dims = size === 'sm' ? { w: 64, h: 92 } : size === 'lg' ? { w: 118, h: 170 } : { w: 88, h: 128 };
  return (
    <View style={[styles.cover, { width: dims.w, height: dims.h, backgroundColor: bg }]}>
      <View style={styles.spine} />
      <View style={styles.band} />
      <Text style={styles.initial}>{title.charAt(0).toUpperCase()}</Text>
      <Text style={styles.title} numberOfLines={2}>{title}</Text>
      <Text style={styles.author} numberOfLines={1}>{author}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  cover: {
    borderRadius: 10, overflow: 'hidden', paddingHorizontal: 10, paddingTop: 12, paddingBottom: 8,
    justifyContent: 'flex-start',
  },
  spine: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 6, backgroundColor: 'rgba(0,0,0,0.22)' },
  band: { position: 'absolute', left: 6, right: 0, top: 34, height: 2, backgroundColor: 'rgba(255,255,255,0.35)' },
  initial: { fontFamily: SERIF, fontSize: 26, fontWeight: '700', color: 'rgba(255,255,255,0.95)' },
  title: { fontFamily: SERIF, fontSize: 12, fontWeight: '700', lineHeight: 15, color: 'rgba(255,255,255,0.95)', marginTop: 2 },
  author: { fontSize: 8, color: 'rgba(255,255,255,0.78)', marginTop: 'auto' },
});
