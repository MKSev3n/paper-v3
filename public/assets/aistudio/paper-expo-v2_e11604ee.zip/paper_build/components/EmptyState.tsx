import { StyleSheet, Text, View } from 'react-native';
import { LightReader, SERIF } from './theme';
import { Ionicons } from '@expo/vector-icons';

export function EmptyState({ title, body, icon = 'book-outline' }: { title: string; body: string; icon?: any }) {
  return (
    <View style={styles.wrap}>
      <View style={styles.iconCircle}><Ionicons name={icon} size={30} color={LightReader.muted} /></View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.body}>{body}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  wrap: { alignItems: 'center', paddingVertical: 56, gap: 8, paddingHorizontal: 28 },
  iconCircle: { width: 64, height: 64, borderRadius: 32, backgroundColor: LightReader.surfaceSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  title: { fontFamily: SERIF, fontSize: 20, fontWeight: '700', color: LightReader.text },
  body: { fontSize: 14, color: LightReader.muted, textAlign: 'center', lineHeight: 20 },
});
