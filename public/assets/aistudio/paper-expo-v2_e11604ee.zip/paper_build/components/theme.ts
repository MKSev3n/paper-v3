import { Platform } from 'react-native';

export const LightReader = {
  // modern Light Reader palette: airy paper, fresh sky blue accent, soft lilac secondary
  background: '#F5F7FA',
  surface: '#FFFFFF',
  surfaceSoft: '#EEF2F7',
  surfaceMuted: '#E7EDF4',
  border: '#DCE4EE',
  borderSoft: '#E9EEF5',
  text: '#1E2A3A',
  textSecondary: '#4A5B70',
  muted: '#8295AC',
  accent: '#2F7DE1',
  accentDeep: '#1D5FAD',
  accentSoft: '#DBEBFC',
  accentTint: '#EFF6FF',
  lilac: '#8B7CF6',
  lilacSoft: '#EFECFE',
  amber: '#C88A2D',
  amberSoft: '#FFF3DC',
  green: '#1F9D6E',
  greenSoft: '#DDF4E7',
  red: '#E35D6A',
  cover: '#FFFFFF',
} as const;

export type LightReaderTokens = typeof LightReader;

// Backwards-compatible alias used by older screens (they import COLORS from here)
export const COLORS = {
  background: LightReader.background,
  surface: LightReader.surface,
  border: LightReader.border,
  text: LightReader.text,
  muted: LightReader.muted,
  accent: LightReader.accent,
} as const;

export const SERIF = Platform.select({ ios: 'Georgia', android: 'serif', default: 'serif' });
export const SANS = Platform.select({ ios: 'System', android: 'sans-serif', default: 'sans-serif' }) as string;

export const radius = { sm: 10, md: 14, lg: 18, xl: 24, pill: 999 } as const;

export const shadows = {
  card: {
    shadowColor: '#1E2A3A',
    shadowOpacity: 0.07,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  pop: {
    shadowColor: '#1E2A3A',
    shadowOpacity: 0.14,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 6,
  },
} as const;
