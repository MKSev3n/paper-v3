import { StyleSheet, Text, View } from 'react-native';
import { LightReader } from './theme';

export function Tag({ label }: { label: string }) {
  return <View style={styles.tag}><Text style={styles.text}>{label}</Text></View>;
}
const styles = StyleSheet.create({
  tag: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999, backgroundColor: LightReader.surfaceSoft },
  text: { fontSize: 11, fontWeight: '600', color: LightReader.textSecondary },
});
