import AsyncStorage from '@react-native-async-storage/async-storage';

export type ThemeName = 'oled' | 'dark' | 'sepia' | 'light';

export interface ReaderSettings {
  theme: ThemeName;
  fontSize: number;
  lineHeight: number; // multiplier, e.g. 1.6
}

export const THEME_NAMES: ThemeName[] = ['oled', 'dark', 'sepia', 'light'];

export const FONT_SIZE_MIN = 12;
export const FONT_SIZE_MAX = 34;
export const FONT_SIZE_STEP = 1;

export const LINE_HEIGHT_MIN = 1.2;
export const LINE_HEIGHT_MAX = 2.4;
export const LINE_HEIGHT_STEP = 0.1;

export const DEFAULT_SETTINGS: ReaderSettings = {
  theme: 'light',
  fontSize: 18,
  lineHeight: 1.6,
};

const SETTINGS_KEY = '@paper/reader-settings:v1';
const SCROLL_PREFIX = '@paper/scroll:v1:';

const scrollKey = (novelId: string): string => `${SCROLL_PREFIX}${novelId}`;

const clamp = (value: number, min: number, max: number): number =>
  Math.min(max, Math.max(min, value));

export const roundLineHeight = (value: number): number =>
  Math.round(clamp(value, LINE_HEIGHT_MIN, LINE_HEIGHT_MAX) * 10) / 10;

/** Validates untrusted stored data and falls back to defaults field by field. */
export function sanitizeSettings(raw: unknown): ReaderSettings {
  if (typeof raw !== 'object' || raw === null) {
    return { ...DEFAULT_SETTINGS };
  }
  const candidate = raw as Partial<Record<keyof ReaderSettings, unknown>>;

  const theme =
    typeof candidate.theme === 'string' &&
    (THEME_NAMES as string[]).includes(candidate.theme)
      ? (candidate.theme as ThemeName)
      : DEFAULT_SETTINGS.theme;

  const fontSize =
    typeof candidate.fontSize === 'number' && Number.isFinite(candidate.fontSize)
      ? Math.round(clamp(candidate.fontSize, FONT_SIZE_MIN, FONT_SIZE_MAX))
      : DEFAULT_SETTINGS.fontSize;

  const lineHeight =
    typeof candidate.lineHeight === 'number' && Number.isFinite(candidate.lineHeight)
      ? roundLineHeight(candidate.lineHeight)
      : DEFAULT_SETTINGS.lineHeight;

  return { theme, fontSize, lineHeight };
}

export async function loadSettings(): Promise<ReaderSettings> {
  try {
    const stored = await AsyncStorage.getItem(SETTINGS_KEY);
    if (!stored) {
      return { ...DEFAULT_SETTINGS };
    }
    return sanitizeSettings(JSON.parse(stored));
  } catch (error) {
    console.warn('[storage] Failed to load settings', error);
    return { ...DEFAULT_SETTINGS };
  }
}

export async function saveSettings(settings: ReaderSettings): Promise<void> {
  try {
    await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.warn('[storage] Failed to save settings', error);
  }
}

const parseOffset = (value: string | null): number => {
  if (value === null) {
    return 0;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
};

/** Returns the saved vertical scroll offset for a novel, or 0 if none. */
export async function loadScrollPosition(novelId: string): Promise<number> {
  try {
    return parseOffset(await AsyncStorage.getItem(scrollKey(novelId)));
  } catch (error) {
    console.warn('[storage] Failed to load scroll position', error);
    return 0;
  }
}

export async function saveScrollPosition(novelId: string, offset: number): Promise<void> {
  if (!Number.isFinite(offset)) {
    return;
  }
  try {
    await AsyncStorage.setItem(scrollKey(novelId), String(Math.max(0, offset)));
  } catch (error) {
    console.warn('[storage] Failed to save scroll position', error);
  }
}

/** Loads saved offsets for many novels at once (used by the library view). */
export async function loadScrollPositions(
  novelIds: string[],
): Promise<Record<string, number>> {
  const result: Record<string, number> = {};
  try {
    const pairs = await AsyncStorage.multiGet(novelIds.map(scrollKey));
    pairs.forEach(([key, value], index) => {
      result[novelIds[index]] = parseOffset(value);
    });
  } catch (error) {
    console.warn('[storage] Failed to load scroll positions', error);
    novelIds.forEach((id) => {
      result[id] = 0;
    });
  }
  return result;
}

export async function clearScrollPosition(novelId: string): Promise<void> {
  try {
    await AsyncStorage.removeItem(scrollKey(novelId));
  } catch (error) {
    console.warn('[storage] Failed to clear scroll position', error);
  }
}
