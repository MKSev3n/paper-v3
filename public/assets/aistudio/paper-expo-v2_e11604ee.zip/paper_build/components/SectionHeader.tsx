import { Pressable, StyleSheet, Text } from 'react-native';
import { LightReader, SERIF } from './theme';

export function SectionHeader({ title, actionLabel, onAction }: { title: string; actionLabel?: string; onAction?: () => void }) {
  return (
    <Pressable style={styles.row} onPress={onAction} disabled={!onAction} accessibilityRole={onAction ? 'button' : undefined}>
      <Text style={styles.title}>{title}</Text>
      {actionLabel ? <Text style={styles.action}>{actionLabel}</Text> : null}
    </Pressable>
  );
}
const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginHorizontal: 20, marginTop: 22, marginBottom: 10 },
  title: { fontFamily: SERIF, fontSize: 19, fontWeight: '700', color: LightReader.text },
  action: { fontSize: 13, fontWeight: '700', color: LightReader.accent },
});
