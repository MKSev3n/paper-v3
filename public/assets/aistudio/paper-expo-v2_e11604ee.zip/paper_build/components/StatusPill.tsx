import { StyleSheet, Text, View } from 'react-native';
import { LightReader } from './theme';

const MAP: Record<string, { bg: string; fg: string }> = {
  Ongoing: { bg: LightReader.greenSoft, fg: LightReader.green },
  Completed: { bg: LightReader.accentSoft, fg: LightReader.accentDeep },
  Hiatus: { bg: LightReader.amberSoft, fg: LightReader.amber },
};

export function StatusPill({ status }: { status: string }) {
  const c = MAP[status] ?? { bg: LightReader.surfaceSoft, fg: LightReader.textSecondary };
  return (
    <View style={[styles.pill, { backgroundColor: c.bg }]}>
      <View style={[styles.dot, { backgroundColor: c.fg }]} />
      <Text style={[styles.text, { color: c.fg }]}>{status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  pill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  text: { fontSize: 11, fontWeight: '700' },
});
