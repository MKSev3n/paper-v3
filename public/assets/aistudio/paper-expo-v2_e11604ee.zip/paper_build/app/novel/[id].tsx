import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { NOVELS, getNovelById, Novel } from '../../data/novels';
import { getNovel, getChapters, listNovels, mapApiNovel, type LiveNovel, type ApiChapter, type ApiNovel } from '../../utils/incrawl';
import { loadScrollPositions } from '../../utils/storage';
import { LightReader, SERIF, shadows } from '../../components/theme';
import { BookCover } from '../../components/BookCover';
import { StatusPill } from '../../components/StatusPill';
import { Tag } from '../../components/Tag';
import { EmptyState } from '../../components/EmptyState';

type Detail = Novel | LiveNovel;

export default function NovelDetail() {
  const { id, live } = useLocalSearchParams<{ id: string; live?: string }>();
  const novelId = typeof id === 'string' ? id : '';
  const isLive = live === '1';
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [apiNovel, setApiNovel] = useState<ApiNovel | null>(null);
  const [chapters, setChapters] = useState<ApiChapter[]>([]);
  const [loading, setLoading] = useState(isLive);
  const [error, setError] = useState('');
  const [related, setRelated] = useState<Detail[]>([]);
  const [progress, setProgress] = useState(0);

  const local = getNovelById(novelId);

  useEffect(() => {
    if (!isLive) return;
    let active = true;
    setLoading(true); setError('');
    Promise.all([getNovel(novelId), getChapters(novelId, 100)]).then(([n, ch]) => {
      if (!active) return;
      setApiNovel(n); setChapters(ch.items);
    }).catch((e) => { if (active) { setError(e instanceof Error ? e.message : 'Could not load this novel.'); } })
    .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [isLive, novelId]);

  useEffect(() => {
    let active = true;
    const baseTags = apiNovel?.tags ?? local?.tags ?? [];
    // related: same tags first, then popular live
    const pick = async () => {
      try {
        const page = await listNovels({ limit: 12, sort: 'popular' });
        if (!active) return;
        const mapped = page.items.map(mapApiNovel).filter((n) => n.id !== novelId);
        const scored = mapped.map((n) => ({ n, score: n.tags.filter((t) => baseTags.includes(t)).length }));
        scored.sort((a, b) => b.score - a.score);
        setRelated(scored.slice(0, 6).map((s) => s.n));
      } catch { /* offline: keep local related */ }
    };
    pick();
    loadScrollPositions([novelId]).then((r) => { if (active) setProgress(r[novelId] ?? 0); });
    return () => { active = false; };
  }, [novelId]);

  const detail: Detail | null = useMemo(() => {
    if (apiNovel) return mapApiNovel(apiNovel);
    if (local) return local;
    return null;
  }, [apiNovel, local]);

  const openChapter = (chapterId?: string) => {
    if (!chapterId && detail && 'paragraphs' in detail) { router.push({ pathname: '/reader/[id]', params: { id: novelId } }); return; }
    if (chapterId) router.push({ pathname: '/reader/[id]', params: { id: novelId, live: '1', chapter: chapterId } });
    else if (chapters[0]) router.push({ pathname: '/reader/[id]', params: { id: novelId, live: '1', chapter: chapters[0].id } });
  };

  const header = (
    <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
      <Pressable onPress={() => router.back()} style={styles.iconBtn} accessibilityLabel="Back"><Ionicons name="chevron-back" size={26} color={LightReader.text} /></Pressable>
      <Text style={styles.headerTitle} numberOfLines={1}>{detail ? detail.title : 'Novel'}</Text>
      <View style={styles.iconBtn} />
    </View>
  );

  if (loading) return <View style={[styles.screen, { paddingBottom: insets.bottom }]}>{header}<View style={styles.center}><ActivityIndicator color={LightReader.accent} /><Text style={styles.muted}>Loading novel…</Text></View></View>;
  if (!detail) return <View style={[styles.screen, { paddingBottom: insets.bottom }]}>{header}<EmptyState title="Novel not found" body={error || 'This novel is no longer in your library.'} /></View>;

  const localChapters: { id: string; title: string }[] = chapters.length
    ? chapters.map((c) => ({ id: c.id, title: `${c.serial + 1}. ${c.title}` }))
    : ('paragraphs' in detail ? [{ id: '', title: detail.chapterTitle }] : []);

  const relatedList = related.length ? related : NOVELS.filter((n) => n.id !== novelId).slice(0, 3);

  return (
    <View style={[styles.screen, { paddingBottom: insets.bottom }]}>
      {header}
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={styles.heroCard}>
          <BookCover id={detail.id} title={detail.title} author={detail.author} color={detail.coverColor} size="lg" />
          <View style={styles.heroText}>
            <Text style={styles.title}>{detail.title}</Text>
            <Text style={styles.author}>by {detail.author}</Text>
            <View style={styles.metaRow}>
              <StatusPill status={detail.status} />
              <Text style={styles.meta}>{detail.chapterCount} chapters</Text>
            </View>
            {detail.tags.length > 0 && <View style={styles.tagRow}>{detail.tags.map((t) => <Tag key={t} label={t} />)}</View>}
            {progress > 0 && <View style={styles.progressChip}><Ionicons name="bookmark" size={12} color={LightReader.accent} /><Text style={styles.progressText}>In progress</Text></View>}
          </View>
        </View>

        <Text style={styles.section}>Synopsis</Text>
        <Text style={styles.synopsis}>{detail.synopsis}</Text>

        <Text style={styles.section}>Chapters {localChapters.length > 0 ? `(${localChapters.length})` : ''}</Text>
        {localChapters.length === 0 ? (
          <Text style={styles.muted}>No chapters listed yet.</Text>
        ) : (
          <View style={styles.chapterCard}>
            {localChapters.slice(0, 50).map((c, i) => (
              <Pressable key={c.id || `local-${i}`} onPress={() => openChapter(c.id)} style={[styles.chapterRow, i === localChapters.length - 1 && styles.chapterRowLast]}>
                <View style={styles.chapterNum}><Text style={styles.chapterNumText}>{i + 1}</Text></View>
                <Text style={styles.chapterTitle} numberOfLines={1}>{c.title}</Text>
                <Ionicons name="chevron-forward" size={18} color={LightReader.muted} />
              </Pressable>
            ))}
          </View>
        )}

        <Text style={styles.section}>You may also like</Text>
        <ScrollView horizontal showsVerticalScrollIndicator={false} contentContainerStyle={styles.relatedRow}>
          {relatedList.map((r) => (
            <Pressable key={r.id} style={styles.relatedCard} onPress={() => router.push({ pathname: '/novel/[id]', params: { id: r.id, ...(('live' in r && r.live) ? { live: '1' } : {}) } })}>
              <BookCover id={r.id} title={r.title} author={r.author} color={r.coverColor} size="sm" />
              <Text style={styles.relatedTitle} numberOfLines={2}>{r.title}</Text>
              <Text style={styles.relatedAuthor} numberOfLines={1}>{r.author}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </ScrollView>

      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + 12 }]}>
        <Pressable style={styles.readBtn} onPress={() => openChapter(chapters[0]?.id)} accessibilityRole="button">
          <Ionicons name="book" size={18} color="#FFFFFF" />
          <Text style={styles.readBtnText}>{progress > 0 ? 'Continue reading' : 'Start reading'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: LightReader.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  muted: { color: LightReader.muted, fontSize: 14 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingBottom: 8 },
  iconBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { flex: 1, textAlign: 'center', fontFamily: SERIF, fontSize: 17, fontWeight: '700', color: LightReader.text },
  heroCard: { flexDirection: 'row', gap: 16, margin: 16, padding: 16, borderRadius: 20, backgroundColor: LightReader.surface, borderWidth: 1, borderColor: LightReader.borderSoft, ...shadows.card },
  heroText: { flex: 1, justifyContent: 'center', gap: 6 },
  title: { fontFamily: SERIF, fontSize: 22, fontWeight: '700', lineHeight: 26, color: LightReader.text },
  author: { fontSize: 14, color: LightReader.textSecondary },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 4 },
  meta: { fontSize: 13, color: LightReader.muted, fontWeight: '600' },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 6 },
  progressChip: { flexDirection: 'row', alignItems: 'center', gap: 5, alignSelf: 'flex-start', marginTop: 8, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 999, backgroundColor: LightReader.accentTint },
  progressText: { fontSize: 12, fontWeight: '700', color: LightReader.accent },
  section: { fontFamily: SERIF, fontSize: 18, fontWeight: '700', color: LightReader.text, marginHorizontal: 20, marginTop: 20, marginBottom: 8 },
  synopsis: { marginHorizontal: 20, fontSize: 15, lineHeight: 22, color: LightReader.textSecondary },
  chapterCard: { marginHorizontal: 16, borderRadius: 16, backgroundColor: LightReader.surface, borderWidth: 1, borderColor: LightReader.borderSoft, overflow: 'hidden', ...shadows.card },
  chapterRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 13, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: LightReader.borderSoft },
  chapterRowLast: { borderBottomWidth: 0 },
  chapterNum: { width: 30, height: 30, borderRadius: 15, backgroundColor: LightReader.accentTint, alignItems: 'center', justifyContent: 'center' },
  chapterNumText: { fontSize: 13, fontWeight: '700', color: LightReader.accent },
  chapterTitle: { flex: 1, fontSize: 14, fontWeight: '600', color: LightReader.text },
  relatedRow: { paddingHorizontal: 16, gap: 14 },
  relatedCard: { width: 84, gap: 6 },
  relatedTitle: { fontFamily: SERIF, fontSize: 13, fontWeight: '700', lineHeight: 16, color: LightReader.text },
  relatedAuthor: { fontSize: 11, color: LightReader.muted },
  bottomBar: { position: 'absolute', left: 16, right: 16, bottom: 0, paddingTop: 10 },
  readBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 52, borderRadius: 16, backgroundColor: LightReader.accent, ...shadows.pop },
  readBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
