import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { LightReader } from '../components/theme';

export default function RootLayout() {
  return (
    <>
      <StatusBar style="dark" />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: LightReader.background },
          headerTintColor: LightReader.accent,
          headerTitleStyle: { fontSize: 20, fontWeight: '700', color: LightReader.text },
          headerShadowVisible: false,
          headerTitleAlign: 'left',
          contentStyle: { backgroundColor: LightReader.background },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="index" options={{ title: 'Paper', headerShown: false }} />
        <Stack.Screen name="login" options={{ title: 'Sign in' }} />
        <Stack.Screen name="reader/[id]" options={{ headerShown: false, animation: 'fade' }} />
      </Stack>
    </>
  );
}
