# Paper v2.0 - Light Reader edition (Expo Router, SDK 58)

Modernized UI on top of the preserved v1 backend, offline samples and working
features (including the book-search fix from paper-expo-fixed.zip).

## What changed in v2.0

- New **Light Reader** theme: airy paper background, white cards, soft sky-blue
  accent, clean sans UI with serif display titles. Shared tokens in
  `components/theme.ts` are used by every screen.
- Home is now a **2-column book grid** with generated covers, status pills,
  chapter counts and Continue badges instead of long list cards.
- Home header has a v2.0 hero card, genre filter chips and a **sort sheet**
  for the live Incrawl library (Popular / Recently updated / Newest / Most
  chapters / Title A-Z), plus pull-to-refresh.
- **Continue reading** rail for on-device novels with saved scroll progress.
- New **Novel detail screen** (`app/novel/[id].tsx`): hero card with cover,
  status, tags and synopsis, a chapter list (tap opens that exact chapter),
  a sticky Start/Continue button, and a "You may also like" row.
- Login is now a card UI with icon inputs, password show/hide and a friendly
  error box.
- Reader themes renamed to match the new palette: Light Reader (now default),
  Cream, Slate, Midnight. Same font-size, line-height, progress and
  scroll-restore behavior, with a nicer chapter drawer and loading/error cards.

## Preserved from v1

- Incrawl API layer (`utils/incrawl.ts`) untouched: login/signup, token storage,
  listNovels search + sort, getNovel, getChapters, readChapter, HTML stripping.
- Offline sample novels (`data/novels.ts`) untouched.
- Scroll-position and reader-settings storage (`utils/storage.ts`) untouched
  apart from the default theme value.
- The debounced live-search fix from paper-expo-fixed.zip is kept (400ms
  debounce, search passed to listNovels).

## Run / build (phone-only)

1. Install Expo Go from the Play Store.
2. Unzip this project (e.g. in Replit/Codespaces), run `npm install` then `npx expo start`.
3. Scan the QR code with Expo Go (use `npx expo start --tunnel` if needed).
4. Verify with `npm run typecheck` and `npx expo export --platform android`.
5. Standalone APK still needs EAS Build: `npx eas build --platform android`
   (this zip is the project, not an APK).
