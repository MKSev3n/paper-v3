import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ScrollViewInstance } from 'react-native';
import {
  Animated,
  AppState,
  LayoutChangeEvent,
  NativeScrollEvent,
  NativeSyntheticEvent,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { getNovelById } from '../../data/novels';
import { contentToParagraphs, getChapters, readChapter, type ApiChapter } from '../../utils/incrawl';
import {
  DEFAULT_SETTINGS,
  FONT_SIZE_MAX,
  FONT_SIZE_MIN,
  FONT_SIZE_STEP,
  LINE_HEIGHT_MAX,
  LINE_HEIGHT_MIN,
  LINE_HEIGHT_STEP,
  THEME_NAMES,
  ReaderSettings,
  ThemeName,
  loadScrollPosition,
  loadSettings,
  roundLineHeight,
  saveScrollPosition,
  saveSettings,
} from '../../utils/storage';

const SERIF = Platform.select({ ios: 'Georgia', android: 'serif', default: 'serif' });

interface ReaderTheme {
  label: string;
  background: string;
  text: string;
  muted: string;
  panel: string;
  border: string;
  accent: string;
  statusBar: 'light' | 'dark';
}

const THEMES: Record<ThemeName, ReaderTheme> = {
  oled: {
    label: 'Midnight',
    background: '#12161F',
    text: '#E4EAF2',
    muted: '#8A99AD',
    panel: '#1B2230',
    border: '#2C3A4E',
    accent: '#7FB2F0',
    statusBar: 'light',
  },
  dark: {
    label: 'Slate',
    background: '#2B3542',
    text: '#E6ECF5',
    muted: '#9FB0C4',
    panel: '#394655',
    border: '#4C5E74',
    accent: '#8FC1FF',
    statusBar: 'light',
  },
  sepia: {
    label: 'Cream',
    background: '#FAF3E3',
    text: '#4A3B2A',
    muted: '#97805F',
    panel: '#F3E7CD',
    border: '#E4D3AC',
    accent: '#2F7DE1',
    statusBar: 'dark',
  },
  light: {
    label: 'Light Reader',
    background: '#F5F7FA',
    text: '#1E2A3A',
    muted: '#8295AC',
    panel: '#FFFFFF',
    border: '#DCE4EE',
    accent: '#2F7DE1',
    statusBar: 'dark',
  },
};

const SAVE_DEBOUNCE_MS = 250;
const RESTORE_FALLBACK_MS = 800;

interface StepperProps {
  label: string;
  value: string;
  theme: ReaderTheme;
  onDecrease: () => void;
  onIncrease: () => void;
  decreaseDisabled: boolean;
  increaseDisabled: boolean;
}

function Stepper({
  label,
  value,
  theme,
  onDecrease,
  onIncrease,
  decreaseDisabled,
  increaseDisabled,
}: StepperProps) {
  return (
    <View style={styles.stepperRow}>
      <Text style={[styles.stepperLabel, { color: theme.muted }]}>{label}</Text>
      <View style={styles.stepperControls}>
        <Pressable
          onPress={onDecrease}
          disabled={decreaseDisabled}
          hitSlop={8}
          style={[
            styles.stepperButton,
            { borderColor: theme.border },
            decreaseDisabled && styles.disabled,
          ]}
          accessibilityRole="button"
          accessibilityLabel={`Decrease ${label}`}
        >
          <Ionicons name="remove" size={20} color={theme.text} />
        </Pressable>
        <Text style={[styles.stepperValue, { color: theme.text }]}>{value}</Text>
        <Pressable
          onPress={onIncrease}
          disabled={increaseDisabled}
          hitSlop={8}
          style={[
            styles.stepperButton,
            { borderColor: theme.border },
            increaseDisabled && styles.disabled,
          ]}
          accessibilityRole="button"
          accessibilityLabel={`Increase ${label}`}
        >
          <Ionicons name="add" size={20} color={theme.text} />
        </Pressable>
      </View>
    </View>
  );
}

export default function ReaderScreen() {
  const { id, live, chapter } = useLocalSearchParams<{ id: string; live?: string; chapter?: string }>();
  const novelId = typeof id === 'string' ? id : '';
  const isLiveRoute = live === '1';
  const localNovel = getNovelById(novelId);

  const [chapters, setChapters] = useState<ApiChapter[]>([]);
  const [chapterId, setChapterId] = useState<string | null>(null);
  const [liveTitle, setLiveTitle] = useState('');
  const [liveAuthor, setLiveAuthor] = useState('');
  const [liveParagraphs, setLiveParagraphs] = useState<string[]>([]);
  const [liveChapterTitle, setLiveChapterTitle] = useState('');
  const [liveState, setLiveState] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [liveError, setLiveError] = useState('');
  const [chapterListVisible, setChapterListVisible] = useState(false);

  // load chapter list, then requested chapter (or first)
  useEffect(() => {
    if (!isLiveRoute || !novelId) return;
    let active = true;
    setLiveState('loading');
    getChapters(novelId)
      .then((page) => {
        if (!active) return;
        setChapters(page.items);
        const requested = typeof chapter === 'string' ? page.items.find((c) => c.id === chapter) : undefined;
        const first = requested ?? page.items[0];
        if (first) setChapterId(first.id);
      })
      .catch((e) => {
        if (!active) return;
        setLiveState('error');
        setLiveError(e instanceof Error ? e.message : 'could not load chapters');
      });
    return () => { active = false; };
  }, [isLiveRoute, novelId, chapter]);

  // load selected chapter content
  useEffect(() => {
    if (!isLiveRoute || !chapterId) return;
    let active = true;
    setLiveState('loading');
    readChapter(chapterId)
      .then((data) => {
        if (!active) return;
        setLiveTitle(data.novel.title);
        setLiveAuthor(data.novel.authors || data.novel.domain || '');
        setLiveChapterTitle(data.chapter.title);
        setLiveParagraphs(contentToParagraphs(data.content));
        setChapterListVisible(false);
        restoredRef.current = false;
        setLiveState('ready');
        setReady(true);
        setContentShown(false);
      })
      .catch((e) => {
        if (!active) return;
        setLiveState('error');
        setLiveError(e instanceof Error ? e.message : 'could not load chapter');
      });
    return () => { active = false; };
  }, [isLiveRoute, chapterId]);

  const novel = isLiveRoute
    ? { title: liveTitle, author: liveAuthor, chapterTitle: liveChapterTitle, paragraphs: liveParagraphs }
    : localNovel;

  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [settings, setSettings] = useState<ReaderSettings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);
  const [uiVisible, setUiVisible] = useState(true);
  const [contentShown, setContentShown] = useState(false);
  const [progressPct, setProgressPct] = useState(0);

  const scrollRef = useRef<ScrollViewInstance>(null);
  const overlayOpacity = useRef(new Animated.Value(1)).current;

  const offsetRef = useRef(0); // latest live scroll offset
  const savedOffsetRef = useRef(0); // offset loaded from storage
  const restoredRef = useRef(false);
  const measuredHeightRef = useRef(0); // content height reported by layout
  const contentHeightRef = useRef(0); // content height reported by scroll events
  const viewportHeightRef = useRef(0);
  const lastPctRef = useRef(-1);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const theme = THEMES[settings.theme];

  // Load persisted settings and the saved scroll position together.
  useEffect(() => {
    let active = true;
    Promise.all([
      loadSettings(),
      novelId ? loadScrollPosition(isLiveRoute && chapterId ? chapterId : novelId) : Promise.resolve(0),
    ]).then(([loadedSettings, offset]) => {
      if (!active) {
        return;
      }
      savedOffsetRef.current = offset;
      offsetRef.current = offset;
      setSettings(loadedSettings);
      setReady(true);
    });
    return () => {
      active = false;
    };
  }, [novelId]);

  // Persist settings whenever the user changes them.
  useEffect(() => {
    if (ready) {
      saveSettings(settings);
    }
  }, [ready, settings]);

  // Fade the overlays in and out when the reader UI is toggled.
  useEffect(() => {
    Animated.timing(overlayOpacity, {
      toValue: uiVisible ? 1 : 0,
      duration: 180,
      useNativeDriver: true,
    }).start();
  }, [uiVisible, overlayOpacity]);

  // Never write a position before the saved one has been restored,
  // otherwise the initial offset of 0 would overwrite it.
  const persistScroll = useCallback(() => {
    if (!novelId || !restoredRef.current) {
      return;
    }
    saveScrollPosition(isLiveRoute && chapterId ? chapterId : novelId, offsetRef.current);
  }, [novelId]);

  const flushScroll = useCallback(() => {
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
      saveTimerRef.current = null;
    }
    persistScroll();
  }, [persistScroll]);

  // Save when the app is backgrounded and when the screen unmounts.
  useEffect(() => {
    const subscription = AppState.addEventListener('change', (state) => {
      if (state !== 'active') {
        flushScroll();
      }
    });
    return () => {
      subscription.remove();
      flushScroll();
    };
  }, [flushScroll]);

  const tryRestore = useCallback((force: boolean) => {
    if (restoredRef.current) {
      return;
    }
    const contentHeight = measuredHeightRef.current;
    const viewportHeight = viewportHeightRef.current;
    if (contentHeight <= 0 || viewportHeight <= 0) {
      return;
    }
    const target = savedOffsetRef.current;
    // Wait until the content is tall enough to reach the saved offset.
    if (!force && target > contentHeight - viewportHeight + 1) {
      return;
    }
    restoredRef.current = true;
    offsetRef.current = target;
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ y: target, animated: false });
      setContentShown(true);
    });
  }, []);

  // Safety net: reveal the text even if layout never reaches the saved offset.
  useEffect(() => {
    if (!ready) {
      return undefined;
    }
    const timer = setTimeout(() => {
      tryRestore(true);
      setContentShown(true);
    }, RESTORE_FALLBACK_MS);
    return () => clearTimeout(timer);
  }, [ready, tryRestore]);

  const handleScrollLayout = useCallback(
    (event: LayoutChangeEvent) => {
      viewportHeightRef.current = event.nativeEvent.layout.height;
      tryRestore(false);
    },
    [tryRestore],
  );

  const handleContentSizeChange = useCallback(
    (_width: number, height: number) => {
      const previous = measuredHeightRef.current;
      measuredHeightRef.current = height;

      if (!restoredRef.current) {
        tryRestore(false);
        return;
      }

      // Font size or line height changed: keep the reader at the same
      // relative place in the text instead of the same pixel offset.
      if (previous > 0 && height > 0 && height !== previous) {
        const target = (offsetRef.current / previous) * height;
        requestAnimationFrame(() => {
          scrollRef.current?.scrollTo({ y: target, animated: false });
        });
      }
    },
    [tryRestore],
  );

  const handleScroll = useCallback(
    (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
      contentHeightRef.current = contentSize.height;
      viewportHeightRef.current = layoutMeasurement.height;

      const maxOffset = contentSize.height - layoutMeasurement.height;
      const pct =
        maxOffset > 0
          ? Math.min(100, Math.max(0, Math.round((contentOffset.y / maxOffset) * 100)))
          : 0;
      if (pct !== lastPctRef.current) {
        lastPctRef.current = pct;
        setProgressPct(pct);
      }

      if (!restoredRef.current) {
        return;
      }
      offsetRef.current = contentOffset.y;
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current);
      }
      saveTimerRef.current = setTimeout(persistScroll, SAVE_DEBOUNCE_MS);
    },
    [persistScroll],
  );

  const toggleUi = useCallback(() => setUiVisible((visible) => !visible), []);

  const handleBack = useCallback(() => {
    flushScroll();
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('/');
    }
  }, [flushScroll, router]);

  const changeFontSize = useCallback((direction: 1 | -1) => {
    setSettings((previous) => ({
      ...previous,
      fontSize: Math.min(
        FONT_SIZE_MAX,
        Math.max(FONT_SIZE_MIN, previous.fontSize + direction * FONT_SIZE_STEP),
      ),
    }));
  }, []);

  const changeLineHeight = useCallback((direction: 1 | -1) => {
    setSettings((previous) => ({
      ...previous,
      lineHeight: roundLineHeight(previous.lineHeight + direction * LINE_HEIGHT_STEP),
    }));
  }, []);

  const selectTheme = useCallback((name: ThemeName) => {
    setSettings((previous) => ({ ...previous, theme: name }));
  }, []);

  const textStyles = useMemo(() => {
    const titleSize = Math.round(settings.fontSize * 1.45);
    return {
      title: {
        fontSize: titleSize,
        lineHeight: Math.round(titleSize * 1.25),
        color: theme.text,
        fontFamily: SERIF,
      },
      body: {
        fontSize: settings.fontSize,
        lineHeight: Math.round(settings.fontSize * settings.lineHeight),
        marginBottom: Math.round(settings.fontSize * 0.9),
        color: theme.text,
        fontFamily: SERIF,
      },
    };
  }, [settings.fontSize, settings.lineHeight, theme.text]);

  if (!ready) {
    return (
      <View
        style={[
          styles.root,
          { backgroundColor: THEMES[DEFAULT_SETTINGS.theme].background },
        ]}
      />
    );
  }

  if (!novel) {
    return (
      <View style={[styles.root, styles.notFound, { backgroundColor: theme.background }]}>
        <StatusBar style={theme.statusBar} />
        <Text style={[styles.notFoundTitle, { color: theme.text }]}>Novel not found</Text>
        <Text style={[styles.notFoundBody, { color: theme.muted }]}>
          This novel is no longer in your library.
        </Text>
        <Pressable
          onPress={handleBack}
          style={[styles.notFoundButton, { borderColor: theme.accent }]}
          accessibilityRole="button"
        >
          <Text style={{ color: theme.accent, fontWeight: '600' }}>Back to library</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar hidden={!uiVisible} style={theme.statusBar} animated />

      <ScrollView
        ref={scrollRef}
        style={[styles.scroll, { opacity: contentShown ? 1 : 0 }]}
        contentContainerStyle={{
          paddingTop: insets.top + 32,
          paddingBottom: insets.bottom + 120,
          paddingHorizontal: 22,
        }}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        onScrollEndDrag={flushScroll}
        onMomentumScrollEnd={flushScroll}
        onContentSizeChange={handleContentSizeChange}
        onLayout={handleScrollLayout}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          onPress={toggleUi}
          style={styles.page}
          accessibilityLabel="Tap to show or hide reader controls"
        >
          <Text style={textStyles.title}>{novel.chapterTitle}</Text>
          <Text style={[styles.byline, { color: theme.muted }]}>{novel.author}</Text>
          <View style={[styles.divider, { backgroundColor: theme.border }]} />
          {novel.paragraphs.map((paragraph, index) => (
            <Text key={index} style={textStyles.body}>
              {paragraph}
            </Text>
          ))}
          <Text style={[styles.endMark, { color: theme.muted }]}>End of chapter</Text>
        </Pressable>
      </ScrollView>

      {isLiveRoute && chapterListVisible && (
        <Pressable style={styles.chapterBackdrop} onPress={() => setChapterListVisible(false)} accessibilityLabel="Close chapter list">
          <Pressable
            style={[styles.chapterOverlay, { backgroundColor: theme.panel, borderColor: theme.border }]}
            onPress={(e) => e.stopPropagation()}
          >
            <Text style={[styles.chapterOverlayTitle, { color: theme.text }]}>Chapters</Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              {chapters.map((c) => {
                const active = c.id === chapterId;
                return (
                  <Pressable key={c.id} onPress={() => setChapterId(c.id)} style={[styles.chapterRow, active && { backgroundColor: theme.accent + '1F', borderRadius: 10 }]} accessibilityRole="button">
                    <Text style={{ color: active ? theme.accent : theme.text, fontWeight: active ? '700' : '400' }} numberOfLines={1}>
                      {c.serial + 1}. {c.title}
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </Pressable>
        </Pressable>
      )}
      {isLiveRoute && liveState === 'loading' && (
        <View style={[styles.liveStatus, { backgroundColor: theme.background }]}>
          <View style={[styles.statusCard, { backgroundColor: theme.panel, borderColor: theme.border }]}>
            <Text style={{ color: theme.muted }}>Loading chapter…</Text>
          </View>
        </View>
      )}
      {isLiveRoute && liveState === 'error' && (
        <View style={[styles.liveStatus, { backgroundColor: theme.background }]}>
          <View style={[styles.statusCard, { backgroundColor: theme.panel, borderColor: theme.border }]}>
            <Text style={{ color: theme.text }}>Could not load: {liveError}</Text>
            <Pressable onPress={() => chapters.length ? setChapterId(chapterId) : router.back()} style={{ marginTop: 12, paddingVertical: 10, paddingHorizontal: 16, borderRadius: 10, backgroundColor: theme.accent }}>
              <Text style={{ color: '#FFFFFF', fontWeight: '700' }}>Retry / Back</Text>
            </Pressable>
          </View>
        </View>
      )}

      <Animated.View
        pointerEvents={uiVisible ? 'auto' : 'none'}
        style={[
          styles.topBar,
          {
            opacity: overlayOpacity,
            paddingTop: insets.top + 8,
            backgroundColor: theme.panel,
            borderBottomColor: theme.border,
          },
        ]}
      >
        <Pressable
          onPress={handleBack}
          hitSlop={10}
          style={styles.backButton}
          accessibilityRole="button"
          accessibilityLabel="Back to library"
        >
          <Ionicons name="chevron-back" size={26} color={theme.text} />
        </Pressable>
        <View style={styles.topTitleWrap}>
          <Text style={[styles.topTitle, { color: theme.text }]} numberOfLines={1}>
            {novel.title}
          </Text>
          <Text style={[styles.topSubtitle, { color: theme.muted }]} numberOfLines={1}>
            {novel.author}
          </Text>
        </View>
        {isLiveRoute && chapters.length > 0 && (
          <Pressable onPress={() => setChapterListVisible((v) => !v)} hitSlop={10} accessibilityRole="button" accessibilityLabel="Chapter list">
            <Ionicons name="list" size={22} color={theme.text} />
          </Pressable>
        )}
        <Text style={[styles.topPct, { color: theme.accent }]}>{progressPct}%</Text>
      </Animated.View>

      <Animated.View
        pointerEvents={uiVisible ? 'auto' : 'none'}
        style={[
          styles.bottomPanel,
          {
            opacity: overlayOpacity,
            paddingBottom: insets.bottom + 14,
            backgroundColor: theme.panel,
            borderTopColor: theme.border,
          },
        ]}
      >
        <View style={[styles.progressTrack, { backgroundColor: theme.border }]}>
          <View
            style={[
              styles.progressFill,
              { width: `${progressPct}%`, backgroundColor: theme.accent },
            ]}
          />
        </View>

        <Stepper
          label="Font size"
          value={`${settings.fontSize}`}
          theme={theme}
          onDecrease={() => changeFontSize(-1)}
          onIncrease={() => changeFontSize(1)}
          decreaseDisabled={settings.fontSize <= FONT_SIZE_MIN}
          increaseDisabled={settings.fontSize >= FONT_SIZE_MAX}
        />
        <Stepper
          label="Line height"
          value={settings.lineHeight.toFixed(1)}
          theme={theme}
          onDecrease={() => changeLineHeight(-1)}
          onIncrease={() => changeLineHeight(1)}
          decreaseDisabled={settings.lineHeight <= LINE_HEIGHT_MIN + 0.001}
          increaseDisabled={settings.lineHeight >= LINE_HEIGHT_MAX - 0.001}
        />

        <View style={styles.themeRow}>
          {THEME_NAMES.map((name) => {
            const preset = THEMES[name];
            const selected = settings.theme === name;
            return (
              <Pressable
                key={name}
                onPress={() => selectTheme(name)}
                style={[
                  styles.themeChip,
                  {
                    borderColor: selected ? theme.accent : theme.border,
                    borderWidth: selected ? 2 : 1,
                  },
                ]}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                accessibilityLabel={`${preset.label} theme`}
              >
                <View
                  style={[
                    styles.themeSwatch,
                    { backgroundColor: preset.background, borderColor: theme.border },
                  ]}
                >
                  <Text style={[styles.themeSwatchText, { color: preset.text }]}>Aa</Text>
                </View>
                <Text
                  style={[
                    styles.themeLabel,
                    { color: selected ? theme.text : theme.muted },
                  ]}
                  numberOfLines={1}
                >
                  {preset.label}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  chapterBackdrop: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 30, backgroundColor: 'rgba(30,42,58,0.35)', flexDirection: 'row', justifyContent: 'flex-end' },
  chapterOverlay: { width: '80%', height: '100%', padding: 16, borderLeftWidth: 1, borderTopLeftRadius: 20, borderBottomLeftRadius: 20 },
  statusCard: { padding: 20, borderRadius: 16, borderWidth: 1, alignItems: 'center', maxWidth: '85%' },
  chapterOverlayTitle: { fontFamily: SERIF, fontSize: 18, fontWeight: '700', marginBottom: 10 },
  chapterRow: { paddingVertical: 10 },
  liveStatus: { position: 'absolute', inset: 0, zIndex: 25, alignItems: 'center', justifyContent: 'center', padding: 24 },
  root: {
    flex: 1,
  },
  scroll: {
    flex: 1,
  },
  page: {
    width: '100%',
    maxWidth: 680,
    alignSelf: 'center',
  },
  byline: {
    marginTop: 8,
    fontSize: 14,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    marginTop: 18,
    marginBottom: 24,
  },
  endMark: {
    marginTop: 12,
    fontSize: 13,
    textAlign: 'center',
  },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    elevation: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingBottom: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topTitleWrap: {
    flex: 1,
  },
  topTitle: {
    fontFamily: SERIF,
    fontSize: 16,
    fontWeight: '700',
  },
  topSubtitle: {
    fontSize: 12,
    marginTop: 1,
  },
  topPct: {
    fontSize: 14,
    fontWeight: '700',
    minWidth: 44,
    textAlign: 'right',
    paddingRight: 6,
  },
  bottomPanel: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    elevation: 10,
    paddingHorizontal: 18,
    paddingTop: 14,
    gap: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  progressTrack: {
    height: 3,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: 3,
    borderRadius: 2,
  },
  stepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  stepperLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  stepperControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  stepperButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperValue: {
    minWidth: 34,
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '700',
  },
  disabled: {
    opacity: 0.35,
  },
  themeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 2,
  },
  themeChip: {
    flex: 1,
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderRadius: 12,
  },
  themeSwatch: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  themeSwatchText: {
    fontFamily: SERIF,
    fontSize: 16,
    fontWeight: '700',
  },
  themeLabel: {
    fontSize: 11,
    fontWeight: '600',
  },
  notFound: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    gap: 10,
  },
  notFoundTitle: {
    fontFamily: SERIF,
    fontSize: 22,
    fontWeight: '700',
  },
  notFoundBody: {
    fontSize: 14,
    textAlign: 'center',
  },
  notFoundButton: {
    marginTop: 8,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
});
