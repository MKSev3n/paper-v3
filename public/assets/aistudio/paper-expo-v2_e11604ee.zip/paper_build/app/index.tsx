import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Modal, Pressable, RefreshControl, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { NOVELS, Novel } from '../data/novels';
import { loadScrollPositions } from '../utils/storage';
import { IncrawlError, getToken, listNovels, mapApiNovel, type LiveNovel, type NovelSort } from '../utils/incrawl';
import { LightReader, shadows } from '../components/theme';
import { BookCover } from '../components/BookCover';
import { StatusPill } from '../components/StatusPill';
import { Tag } from '../components/Tag';
import { SectionHeader } from '../components/SectionHeader';
import { EmptyState } from '../components/EmptyState';

type HomeNovel = Novel | LiveNovel;
const isLive = (n: HomeNovel): n is LiveNovel => 'live' in n && (n as LiveNovel).live === true;

const SORTS: { key: NovelSort; label: string }[] = [
  { key: 'popular', label: 'Popular' },
  { key: 'updated', label: 'Recently updated' },
  { key: 'created', label: 'Newest' },
  { key: 'chapters', label: 'Most chapters' },
  { key: 'title_asc', label: 'Title A-Z' },
];

const GENRES = ['All', 'Fantasy', 'Sci-Fi', 'Romance', 'Adventure', 'Slice of Life', 'Cozy'];

function NovelGridCard({ novel, inProgress, onPress }: { novel: HomeNovel; inProgress: boolean; onPress: (n: HomeNovel) => void }) {
  return (
    <Pressable style={styles.gridCard} onPress={() => onPress(novel)} accessibilityRole="button" accessibilityLabel={`Open ${novel.title}`}>
      <BookCover id={novel.id} title={novel.title} author={novel.author} color={novel.coverColor} size="md" />
      <Text style={styles.gridTitle} numberOfLines={2}>{novel.title}</Text>
      <Text style={styles.gridAuthor} numberOfLines={1}>{novel.author}</Text>
      <View style={styles.gridMeta}>
        <StatusPill status={novel.status} />
        <Text style={styles.gridChapters}>{novel.chapterCount} ch</Text>
      </View>
      {inProgress && <View style={styles.continueBadge}><Ionicons name="bookmark" size={11} color={LightReader.accent} /><Text style={styles.continueText}>Continue</Text></View>}
    </Pressable>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [query, setQuery] = useState('');
  const [positions, setPositions] = useState<Record<string, number>>({});
  const [live, setLive] = useState<LiveNovel[]>([]);
  const [liveState, setLiveState] = useState<'loading' | 'ready' | 'needs-login' | 'error'>('loading');
  const [liveError, setLiveError] = useState('');
  const [sort, setSort] = useState<NovelSort>('popular');
  const [genre, setGenre] = useState('All');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [sortVisible, setSortVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { const t = setTimeout(() => setDebouncedQuery(query.trim()), 400); return () => clearTimeout(t); }, [query]);

  const loadLive = useCallback(async (search = '', s: NovelSort = sort, silent = false) => {
    if (!silent) { setLiveState('loading'); setLiveError(''); }
    try {
      if (!(await getToken())) { setLiveState('needs-login'); return; }
      const page = await listNovels({ limit: 20, sort: s, search: search || undefined });
      setLive(page.items.map(mapApiNovel));
      setLiveState('ready');
    } catch (e) {
      if (e instanceof IncrawlError && e.status === 401) { setLiveState('needs-login'); return; }
      setLiveState('error');
      setLiveError(e instanceof Error ? e.message : 'live fetch failed');
    } finally { setRefreshing(false); }
  }, [sort]);

  useEffect(() => { loadLive(debouncedQuery, sort); }, [debouncedQuery, sort, loadLive]);

  useFocusEffect(useCallback(() => {
    let active = true;
    loadScrollPositions(NOVELS.map((n) => n.id)).then((r) => { if (active) setPositions(r); });
    return () => { active = false; };
  }, []));

  const openNovel = useCallback((novel: HomeNovel) => {
    router.push({ pathname: '/novel/[id]', params: isLive(novel) ? { id: novel.id, live: '1' } : { id: novel.id } });
  }, [router]);

  const localFiltered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return NOVELS.filter((n) => {
      const genreOk = genre === 'All' || n.tags.includes(genre);
      if (!genreOk) return false;
      if (!needle) return true;
      return n.title.toLowerCase().includes(needle) || n.author.toLowerCase().includes(needle) || n.synopsis.toLowerCase().includes(needle) || n.tags.some((t) => t.toLowerCase().includes(needle));
    });
  }, [query, genre]);

  const liveFiltered = useMemo(() => {
    if (genre === 'All') return live;
    return live.filter((n) => n.tags.includes(genre));
  }, [live, genre]);

  const hasQuery = query.trim().length > 0;
  const continueReading = NOVELS.filter((n) => (positions[n.id] ?? 0) > 0);

  const ListHeader = () => (
    <View>
      <View style={[styles.hero, { marginTop: insets.top + 10 }]}>
        <Text style={styles.heroKicker}>PAPER V2.0</Text>
        <Text style={styles.heroTitle}>Read light novels, beautifully.</Text>
        <Text style={styles.heroSub}>Your library, live updates and a calmer reader.</Text>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={19} color={LightReader.muted} />
          <TextInput value={query} onChangeText={setQuery} placeholder="Search title, author or genre" placeholderTextColor={LightReader.muted} style={styles.searchInput} autoCapitalize="none" autoCorrect={false} returnKeyType="search" accessibilityLabel="Search library" />
          {query.length > 0 && <Pressable onPress={() => setQuery('')} hitSlop={10} accessibilityLabel="Clear search"><Ionicons name="close-circle" size={19} color={LightReader.muted} /></Pressable>}
        </View>
        <View style={styles.chipRow}>
          {GENRES.map((g) => (
            <Pressable key={g} onPress={() => setGenre(g)} style={[styles.chip, genre === g && styles.chipActive]} accessibilityRole="button">
              <Text style={[styles.chipText, genre === g && styles.chipTextActive]}>{g}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      {continueReading.length > 0 && !hasQuery && (
        <View>
          <SectionHeader title="Continue reading" />
          <FlatList horizontal data={continueReading} keyExtractor={(i) => i.id} showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.hRow}
            renderItem={({ item }) => (
              <Pressable style={styles.continueCard} onPress={() => openNovel(item)} accessibilityRole="button">
                <BookCover id={item.id} title={item.title} author={item.author} color={item.coverColor} size="sm" />
                <View style={styles.continueTextWrap}>
                  <Text style={styles.continueTitle} numberOfLines={2}>{item.title}</Text>
                  <View style={styles.pickUpRow}><Ionicons name="play-circle" size={14} color={LightReader.accent} /><Text style={styles.pickUpText}>Pick up</Text></View>
                </View>
              </Pressable>
            )} />
        </View>
      )}

      {liveState === 'needs-login' && (
        <Pressable onPress={() => router.push('/login')} style={styles.loginCard} accessibilityRole="button">
          <View style={styles.loginIcon}><Ionicons name="cloud-offline-outline" size={22} color={LightReader.accent} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.loginTitle}>Live library is offline</Text>
            <Text style={styles.loginBody}>Sign in to browse the live catalogue. Your on-device novels still work.</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={LightReader.muted} />
        </Pressable>
      )}
      {liveState === 'error' && (
        <Pressable onPress={() => loadLive(debouncedQuery, sort)} style={styles.loginCard} accessibilityRole="button">
          <View style={styles.loginIcon}><Ionicons name="refresh-outline" size={22} color={LightReader.accent} /></View>
          <View style={{ flex: 1 }}><Text style={styles.loginTitle}>Could not load live library</Text><Text style={styles.loginBody}>{liveError}. Tap to retry.</Text></View>
        </Pressable>
      )}
      {liveState === 'loading' && <View style={styles.loadingRow}><ActivityIndicator color={LightReader.accent} /><Text style={styles.muted}>Loading live novels…</Text></View>}

      {liveFiltered.length > 0 && (
        <View>
          <SectionHeader title="Live from Incrawl" actionLabel={SORTS.find((s) => s.key === sort)?.label ?? 'Popular'} onAction={() => setSortVisible(true)} />
          <View style={styles.grid}>
            {liveFiltered.map((n) => <NovelGridCard key={`live-${n.id}`} novel={n} inProgress={false} onPress={openNovel} />)}
          </View>
        </View>
      )}

      <SectionHeader title={hasQuery ? `On this device (${localFiltered.length})` : 'On this device'} />
    </View>
  );

  return (
    <View style={styles.screen}>
      <FlatList
        data={localFiltered}
        keyExtractor={(i) => i.id}
        numColumns={2}
        ListHeaderComponent={<ListHeader />}
        renderItem={({ item }) => <NovelGridCard novel={item} inProgress={(positions[item.id] ?? 0) > 0} onPress={openNovel} />}
        columnWrapperStyle={styles.grid}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 28 }]}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadLive(debouncedQuery, sort, true); }} tintColor={LightReader.accent} />}
        ListEmptyComponent={<EmptyState title="No novels found" body="Try a different title, author or genre." />}
      />

      <Modal visible={sortVisible} transparent animationType="fade" onRequestClose={() => setSortVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setSortVisible(false)}>
          <View style={[styles.modalSheet, { paddingBottom: insets.bottom + 18 }]}>
            <Text style={styles.modalTitle}>Sort live library</Text>
            {SORTS.map((s) => (
              <Pressable key={s.key} style={styles.modalRow} onPress={() => { setSort(s.key); setSortVisible(false); }} accessibilityRole="button">
                <Text style={[styles.modalLabel, sort === s.key && styles.modalLabelActive]}>{s.label}</Text>
                {sort === s.key && <Ionicons name="checkmark" size={20} color={LightReader.accent} />}
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: LightReader.background },
  list: { flexGrow: 1 },
  hero: { marginHorizontal: 16, padding: 18, borderRadius: 22, backgroundColor: LightReader.surface, borderWidth: 1, borderColor: LightReader.borderSoft, ...shadows.card },
  heroKicker: { fontSize: 11, fontWeight: '800', letterSpacing: 1.2, color: LightReader.accent },
  heroTitle: { fontSize: 26, fontWeight: '800', lineHeight: 32, color: LightReader.text, marginTop: 6 },
  heroSub: { fontSize: 14, color: LightReader.textSecondary, marginTop: 6, lineHeight: 20 },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14, paddingHorizontal: 14, height: 48, borderRadius: 14, backgroundColor: LightReader.surfaceSoft, borderWidth: 1, borderColor: LightReader.borderSoft },
  searchInput: { flex: 1, color: LightReader.text, fontSize: 15, paddingVertical: 0 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, backgroundColor: LightReader.surfaceSoft, borderWidth: 1, borderColor: LightReader.borderSoft },
  chipActive: { backgroundColor: LightReader.accent, borderColor: LightReader.accent },
  chipText: { fontSize: 13, fontWeight: '600', color: LightReader.textSecondary },
  chipTextActive: { color: '#FFFFFF' },
  hRow: { paddingHorizontal: 16, gap: 12 },
  continueCard: { flexDirection: 'row', gap: 12, width: 260, padding: 12, borderRadius: 16, backgroundColor: LightReader.surface, borderWidth: 1, borderColor: LightReader.borderSoft, ...shadows.card },
  continueTextWrap: { flex: 1, justifyContent: 'center', gap: 8 },
  continueTitle: { fontSize: 15, fontWeight: '700', lineHeight: 19, color: LightReader.text },
  pickUpRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  pickUpText: { fontSize: 13, fontWeight: '700', color: LightReader.accent },
  loginCard: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: 16, marginTop: 16, padding: 14, borderRadius: 16, backgroundColor: LightReader.accentTint, borderWidth: 1, borderColor: LightReader.accentSoft },
  loginIcon: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  loginTitle: { fontSize: 15, fontWeight: '700', color: LightReader.text },
  loginBody: { fontSize: 13, color: LightReader.textSecondary, marginTop: 2, lineHeight: 18 },
  loadingRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 20, marginTop: 18 },
  muted: { color: LightReader.muted, fontSize: 14 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 10, gap: 10 },
  gridCard: { width: '47.5%', padding: 10, borderRadius: 16, backgroundColor: LightReader.surface, borderWidth: 1, borderColor: LightReader.borderSoft, gap: 6, ...shadows.card },
  gridTitle: { fontSize: 14, fontWeight: '700', lineHeight: 18, color: LightReader.text },
  gridAuthor: { fontSize: 12, color: LightReader.muted },
  gridMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 },
  gridChapters: { fontSize: 12, fontWeight: '600', color: LightReader.muted },
  continueBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999, backgroundColor: LightReader.accentTint },
  continueText: { fontSize: 11, fontWeight: '700', color: LightReader.accent },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(30,42,58,0.35)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: LightReader.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 18 },
  modalTitle: { fontSize: 17, fontWeight: '800', color: LightReader.text, marginBottom: 8 },
  modalRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 13 },
  modalLabel: { fontSize: 15, color: LightReader.textSecondary },
  modalLabelActive: { fontWeight: '700', color: LightReader.accent },
});
