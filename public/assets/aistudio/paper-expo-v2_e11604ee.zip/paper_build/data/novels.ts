export type NovelStatus = 'Ongoing' | 'Completed' | 'Hiatus';

export interface Novel {
  id: string;
  title: string;
  author: string;
  tags: string[];
  status: NovelStatus;
  chapterCount: number;
  coverColor: string;
  synopsis: string;
  chapterTitle: string;
  paragraphs: string[];
}

export const NOVELS: Novel[] = [
  {
    id: 'lantern-cartographer',
    title: 'The Lantern Cartographer',
    author: 'Imani Okafor',
    tags: ['Fantasy', 'Adventure'],
    status: 'Ongoing',
    chapterCount: 48,
    coverColor: '#7A4B2A',
    synopsis:
      'A mapmaker who can only chart places by lantern light follows the dark between kingdoms.',
    chapterTitle: 'Chapter 1: The Unlit Road',
    paragraphs: [
      'Nadia carried three lanterns and never lit more than one. The first burned amber and showed her roads. The second burned blue and showed her water. The third had not been lit since her teacher died, and she kept it wrapped in oilcloth at the bottom of her pack.',
      'The village of Harrow Ford lay at the end of a road that did not appear on any official map. That was the reason she had come. Maps, her teacher used to say, were arguments about what mattered, and the kingdom had decided Harrow Ford did not.',
      'She reached the first houses at dusk. Nobody stood in the doorways. Smoke rose from only two chimneys, and the silence had the careful quality of people listening through walls.',
      'An old man opened a shutter and studied her instruments with open suspicion. "You are the one who draws," he said. It was not a question. "Then draw this: the road behind you is shorter than it was yesterday."',
      'Nadia turned. The road she had walked for six hours was still there, pale in the failing light. But the old man was right, and she felt it before she could measure it. The hills she had crossed stood closer together than they should have.',
      'She lit the amber lantern and held it high. The flame leaned toward the village, as if the road were being drawn in by a slow breath. Along its edges, faint lines of silver thread shimmered, stitching the land together and pulling it tight.',
      '"Who is doing this?" she asked.',
      'The old man closed the shutter halfway. "Nobody is doing it," he said. "Somebody stopped doing something. That is worse. Come inside before the light goes, and I will tell you who used to tend the road."',
      'Nadia hesitated at the threshold. Behind her, the wrapped lantern pressed against her spine like a held breath. She had promised herself she would never light it, and she had promised herself she would find out what happened to her teacher.',
      'The door was warm. She stepped through, and for the first time in a year, she did not check which direction the road was leaning.',
    ],
  },
  {
    id: 'salt-and-static',
    title: 'Salt and Static',
    author: 'Daichi Morimoto',
    tags: ['Sci-Fi', 'Slice of Life'],
    status: 'Completed',
    chapterCount: 112,
    coverColor: '#24506B',
    synopsis:
      'The keeper of a drowned-city radio station answers calls from a world that has forgotten the shore.',
    chapterTitle: 'Chapter 1: Signal at Low Tide',
    paragraphs: [
      'The station sat on stilts above what used to be the financial district. At low tide, Rin could see the tops of traffic lights glowing faintly green under the water, still obeying a schedule nobody had cancelled.',
      'She switched on the transmitter at six, the way she did every evening. The old valves warmed with a smell of dust and hot copper. Somewhere out on the grey water, someone would be waiting for a voice that sounded like land.',
      '"This is Station Nine, broadcasting from the Old Exchange," she said. "Tide is falling. Wind is light from the west. If you can hear me, you are not alone out there."',
      'Most nights, nothing answered. Tonight the receiver gave a small cough of static, and a child\'s voice came through, thin and very far away. "Hello? Is this the radio lady? My grandfather says you are not real."',
      'Rin laughed before she could stop herself. She had not laughed in front of the microphone in two years. "I am as real as the salt in your tea," she said. "What is your name, and where are you broadcasting from?"',
      '"Pim," said the child. "I am on the roof of the green boat. Grandfather says we cannot come ashore because the shore went away."',
      'Rin looked at the window, where the sunset made a long copper road across the water. The shore had not gone away. It had only learned to hide under the tide, with its streets and its stairways and its patient lights.',
      '"The shore is still here," she told him. "It is only sleeping. Tell your grandfather I will keep the lamp on, and when the water drops again you can follow the light."',
      'There was a long pause. Then the static cleared, and an older voice, rough as rope, said a single word she had not heard in years: "Thanks." The channel closed. Rin sat very still, one hand resting on the warm valve, listening to the sea.',
    ],
  },
  {
    id: 'quiet-hours-at-the-bakery',
    title: 'Quiet Hours at the Bakery',
    author: 'Sofia Alvarenga',
    tags: ['Romance', 'Cozy'],
    status: 'Hiatus',
    chapterCount: 23,
    coverColor: '#8A3A52',
    synopsis:
      'Two night-shift bakers learn each other\'s lives one loaf at a time, between midnight and dawn.',
    chapterTitle: 'Chapter 1: Proofing',
    paragraphs: [
      'The ovens came on at midnight, and Mara had learned to trust that sound the way other people trust church bells. A low hum, then a long exhale of heat, and the whole shop began to smell like the first good thing of the day.',
      'She was alone for exactly forty minutes every night. Then the back door would open, letting in a thread of cold air, and Tomas would arrive with flour already on his sleeves and an apology already on his lips.',
      '"Traffic," he said, though there was never any traffic at that hour. Mara had stopped pointing it out around the third week.',
      'They worked in an easy kind of silence, passing trays and tools without speaking. He shaped the rolls with a quick, careful twist. She scored the loaves in long, confident lines. Neither of them had ever mentioned how well their rhythms fit.',
      'At three in the morning the dough needed time, and so did they. Tomas pulled two stools beside the proofing cabinet and handed her a cup of tea that had gone lukewarm exactly the way she liked it.',
      '"Tell me something true," he said. It was a game they had invented without agreeing to it. One true thing each night, nothing too large, nothing that needed an answer.',
      'Mara turned the cup in her hands. "I applied to a pastry school in Lyon," she said. "Two years ago. I never told anyone, and I never went."',
      'Tomas did not say that she should go, or that she should stay. He only nodded slowly and watched the dough rise under its cloth, as though it were doing something very difficult and very brave.',
      '"That is a good true thing," he said at last. "I will keep it safe." And in the soft yellow light, with the oven humming behind them, Mara felt the unfamiliar weight of being known.',
    ],
  },
];

export const getNovelById = (id: string | undefined): Novel | undefined =>
  NOVELS.find((novel) => novel.id === id);
